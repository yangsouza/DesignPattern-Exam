## Purpose

Short, actionable rules to help an AI coding agent be productive in this repository.

## Big picture

- This workspace contains several exercises (Questao1..Questao5). Each `QuestaoN` is an independent Java exercise. Work for grading or examples is isolated per folder.
- Focus example: `Questao2` implements a Strategy pattern for calculating client risk. Key packages: `com.invest.risco.app`, `com.invest.risco.model`, `com.invest.risco.service`, `com.invest.risco.strategy`.

## Entry points & important files

- `Questao2/app/Main.Java` — main runner used by instructors/tests. Use this when verifying behavior for question 2.
- `Questao2/service/CalculadoraDeRisco.Java` — orchestrates risk calculation and holds the Strategy reference.
- `Questao2/strategy/RiskStrategy.Java` — interface for risk models. Implementations should be placed in the same package (e.g., `ModeloAgressivo`, `ModeloModerado`, `ModeloConservador`).
- `Questao2/model/Cliente.Java` — simple data holder used by strategies.

## Patterns & conventions the agent should follow

- Package layout mirrors the folder layout. Use `package com.invest.risco.<folder>` at top of files.
- Strategy pattern: `CalculadoraDeRisco` expects a `RiskStrategy` implementation set via `setStrategy(...)` and calls `calcular(...)`. Add new strategies as classes in `Questao2/strategy` implementing `RiskStrategy` and a `calcularRisco(Cliente)` method.
- Keep implementations small and focused: strategies operate only on `Cliente` getters (`getIdade`, `getRendaMensal`, `getPatrimonio`). Example reference: `CalculadoraDeRisco.Java` calls `strategy.calcularRisco(cliente)` and throws when strategy is null — preserve that behavior.

## Build / run / debug (concrete commands)

This project has no build tool config (no Maven/Gradle). Use the JDK directly.

PowerShell (from repository root) — compile and run Questao2:

```powershell
$files = Get-ChildItem -Path .\Questao2 -Recurse -Filter *.java | Select-Object -ExpandProperty FullName
javac -d out $files
java -cp out com.invest.risco.app.Main
```

Notes:
- `javac -d out` places .class files under `out` following package dirs. Adjust the path if running from a subfolder.
- If `Main` references missing strategy classes (e.g., `ModeloAgressivo`), implement them in `Questao2/strategy` with package `com.invest.risco.strategy`.
 - Ensure a JDK is installed and `javac` is available on PATH. If PowerShell reports `javac` not found, set `JAVA_HOME` and add `%JAVA_HOME%\bin` to your PATH or invoke the full `javac` path.

## Project-specific guidance for code edits

- When adding classes, follow the existing package names and folder structure. Example: a new strategy implementation file should begin with `package com.invest.risco.strategy;`.
- Preserve checked behavior: `CalculadoraDeRisco.calcular` throws IllegalStateException when no strategy is set — avoid removing it unless the test indicates otherwise.
- Unit tests are not present; run `Main` to do quick behavioral checks.

## Integration & missing pieces

- The repo expects strategy implementations referenced from `Main.Java`; if they are absent, implement simple deterministic logic (use `Cliente` fields) so `Main` prints three numeric values.

## Examples to follow

- Minimal strategy skeleton (follow this exact shape):

```java
package com.invest.risco.strategy;

import com.invest.risco.model.Cliente;

public class ModeloAgressivo implements RiskStrategy {
    public double calcularRisco(Cliente c) { return /* deterministic formula */ 0.0; }
}
```

## When to ask for clarification

- If tasks require adding cross-question changes (modifying packages used by multiple `QuestaoN` folders), ask which question's behavior is authoritative.

---

If anything here looks off or you'd like more examples (e.g., a ready-to-compile ModeloAgressivo/Moderado/Conservador), tell me which one to add and I'll implement and verify it.
