package logistica.relatorios;

// A interface 'Produto'
public interface Relatorio {
    void prepararDados();
    void formatar();
    void emitir();
}